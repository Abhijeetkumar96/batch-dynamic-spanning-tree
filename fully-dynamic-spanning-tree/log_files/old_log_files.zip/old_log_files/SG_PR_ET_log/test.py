import re
import csv
import os
import glob

def write_data_to_csv(data, output_file):
    if data:
        keys = data[0].keys()  # Get all the keys from the first dictionary as headers
        with open(output_file, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=keys)
            writer.writeheader()
            for record in data:
                writer.writerow(record)


def parse_log_file(filepath):
    data = []
    current_record = {}
    
    with open(filepath, 'r') as file:
        for line in file:
            # Extract filename
            if "filename:" in line:
                filename_full_path = re.search(r"filename: (\S+)", line)
                if filename_full_path:
                    full_path = filename_full_path.group(1)
                    # Use os.path to split the path and extract the base name without extension
                    base_name = os.path.basename(full_path)  # Gets 'arabic-2005.egr'
                    specific_name = os.path.splitext(base_name)[0]  # Split off the extension
                    current_record['filename'] = specific_name
            
            # Extract number of vertices and edges
            elif "numVertices" in line:
                vertices = re.search(r"numVertices : (\d+), numEdges : (\d+)", line)
                if vertices:
                    current_record['numVertices'] = int(vertices.group(1))
                    current_record['numEdges'] = int(vertices.group(2))

            elif "Depth" in line:
            	tree_depth = re.search(r"Depth of tree: (\d+)", line)
            	if tree_depth:
            		current_record['tree_depth'] = int(tree_depth.group(1))
            
            elif "Reading" in line:
            	batch_size = re.search(r"Reading (\d+) edges from the file", line)
            	if batch_size:
            		current_record['batch_size'] = int(batch_size.group(1))

            elif "Total elapsed time for cudaBFS" in line:
            	cuda_bfs = re.search(r"Total elapsed time for cudaBFS: (\d+) ms", line)
            	if cuda_bfs:
            		current_record['cuda_bfs'] = int(cuda_bfs.group(1))

            elif "Total elapsed time for adam mgpu_BFS" in line:
            	adam_bfs = re.search(r"Total elapsed time for adam mgpu_BFS: (\d+) ms", line)
            	if adam_bfs:
            		current_record['adam_bfs'] = int(adam_bfs.group(1))

            elif "numTreeEdges:" in line:
            	tree_edges_count = re.search(r"numTreeEdges: (\d+)", line)
            	if tree_edges_count:
            		current_record['tree_edges_count'] = int(tree_edges_count.group(1))

            elif "Total elapsed time for dynamic_spanning_tree repair:" in line:
                dynamic_tree = re.search(r"Total elapsed time for dynamic_spanning_tree repair: (\d+) ms", line)
                if dynamic_tree:
                    current_record['dynamic_tree'] = int(dynamic_tree.group(1))  # Use group(1) to get the number only

            # Reset for new record after each block or handle continuation conditions
            elif "numComp after edge deletion:" in line:
                data.append(current_record)
                current_record = {}  # Reset for the next block of data

    return data

# Usage example
# file_path = 'uk-2002.log'
# parsed_data = parse_log_file(file_path)
# print(parsed_data)

# Call the function to write data to CSV
# output_csv_path = 'output_data.csv'
# write_data_to_csv(parsed_data, output_csv_path)


# Find all .log files in the current directory
log_files = glob.glob('*.log')

# Loop through all log files and process them
for log_file in log_files:
    parsed_data = parse_log_file(log_file)
    
    # Generate the output CSV filename based on the log file name
    output_csv_path = os.path.splitext(log_file)[0] + '_output_data.csv'
    
    # Write the parsed data to the corresponding CSV file
    write_data_to_csv(parsed_data, output_csv_path)
    print(f"Data from {log_file} has been written to {output_csv_path}")